<template>
  <CurriculumWeb />
</template>

<script setup>
import CurriculumWeb from './components/CurriculoWeb.vue';
</script>

<style>
body {
  margin: 0;
  padding: 0;
  background-color: #eef2f5;
}

</style>